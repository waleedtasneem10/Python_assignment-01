import os
import joblib
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

# Absolute paths so it works on PythonAnywhere as well as locally
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model = joblib.load(os.path.join(BASE_DIR, "model", "model.joblib"))
scaler = joblib.load(os.path.join(BASE_DIR, "model", "scaler.joblib"))
feature_columns = joblib.load(os.path.join(BASE_DIR, "model", "feature_columns.joblib"))

# Allowed values for every categorical field (used for dropdowns AND validation)
YN = ["Yes", "No"]
ADDON = ["Yes", "No", "No internet service"]
CHOICES = {
    "gender": ["Female", "Male"],
    "Partner": YN,
    "Dependents": YN,
    "PhoneService": YN,
    "MultipleLines": ["Yes", "No", "No phone service"],
    "InternetService": ["DSL", "Fiber optic", "No"],
    "OnlineSecurity": ADDON,
    "OnlineBackup": ADDON,
    "DeviceProtection": ADDON,
    "TechSupport": ADDON,
    "StreamingTV": ADDON,
    "StreamingMovies": ADDON,
    "Contract": ["Month-to-month", "One year", "Two year"],
    "PaperlessBilling": YN,
    "PaymentMethod": ["Electronic check", "Mailed check",
                      "Bank transfer (automatic)", "Credit card (automatic)"],
}
LABELS = {
    "gender": "Gender", "SeniorCitizen": "Senior Citizen", "Partner": "Has Partner",
    "Dependents": "Has Dependents", "tenure": "Tenure (months)",
    "PhoneService": "Phone Service", "MultipleLines": "Multiple Lines",
    "InternetService": "Internet Service", "OnlineSecurity": "Online Security",
    "OnlineBackup": "Online Backup", "DeviceProtection": "Device Protection",
    "TechSupport": "Tech Support", "StreamingTV": "Streaming TV",
    "StreamingMovies": "Streaming Movies", "Contract": "Contract Type",
    "PaperlessBilling": "Paperless Billing", "PaymentMethod": "Payment Method",
    "MonthlyCharges": "Monthly Charges", "TotalCharges": "Total Charges",
}
ADDON_FIELDS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                "TechSupport", "StreamingTV", "StreamingMovies"]


def parse_number(form, name, low, high, errors):
    raw = (form.get(name) or "").strip()
    if raw == "":
        errors.append(f"{LABELS[name]} is required.")
        return None
    try:
        value = float(raw)
    except ValueError:
        errors.append(f"{LABELS[name]} must be a number.")
        return None
    if not (low <= value <= high):
        errors.append(f"{LABELS[name]} must be between {low} and {high}.")
        return None
    return value


def validate(form):
    """Return (clean_row_dict, errors_list)."""
    errors, row = [], {}

    for field, options in CHOICES.items():
        value = (form.get(field) or "").strip()
        if value == "":
            errors.append(f"Please select a value for {LABELS[field]}.")
        elif value not in options:
            errors.append(f"Invalid value for {LABELS[field]}.")
        else:
            row[field] = value

    senior = (form.get("SeniorCitizen") or "").strip()
    if senior not in ("0", "1"):
        errors.append("Please select a value for Senior Citizen.")
    else:
        row["SeniorCitizen"] = int(senior)

    tenure = parse_number(form, "tenure", 0, 100, errors)
    monthly = parse_number(form, "MonthlyCharges", 0, 500, errors)
    if tenure is not None:
        row["tenure"] = int(tenure)
    if monthly is not None:
        row["MonthlyCharges"] = monthly

    # Total charges: optional -> estimate as tenure x monthly if left blank
    raw_total = (form.get("TotalCharges") or "").strip()
    if raw_total == "":
        if tenure is not None and monthly is not None:
            row["TotalCharges"] = round(tenure * monthly, 2)
    else:
        total = parse_number(form, "TotalCharges", 0, 100000, errors)
        if total is not None:
            row["TotalCharges"] = total

    if errors:
        return None, errors

    # Make dependent fields consistent with the dataset's conventions
    if row["PhoneService"] == "No":
        row["MultipleLines"] = "No phone service"
    if row["InternetService"] == "No":
        for f in ADDON_FIELDS:
            row[f] = "No internet service"
    return row, []


def preprocess(row):
    """Same steps as training: get_dummies(drop_first) -> align columns -> scale."""
    df = pd.DataFrame([row])
    df = pd.get_dummies(df)  # baseline categories (drop_first) simply become all-zero after reindex
    df = df.reindex(columns=feature_columns, fill_value=0).astype(float)
    return scaler.transform(df)


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", choices=CHOICES, labels=LABELS,
                           form={}, errors=[], result=None)


@app.route("/predict", methods=["POST"])
def predict():
    row, errors = validate(request.form)
    if errors:
        return render_template("index.html", choices=CHOICES, labels=LABELS,
                               form=request.form, errors=errors, result=None)
    try:
        X = preprocess(row)
        pred = int(model.predict(X)[0])
        prob = float(model.predict_proba(X)[0][1])
    except Exception:
        return render_template("index.html", choices=CHOICES, labels=LABELS,
                               form=request.form, result=None,
                               errors=["Something went wrong while making the prediction. "
                                       "Please check your inputs and try again."])
    result = {
        "label": "Churn" if pred == 1 else "No Churn",
        "churn": pred == 1,
        "probability": round(prob * 100, 1),
        "message": ("This customer is likely to leave the company. Consider a retention offer."
                    if pred == 1 else
                    "This customer is likely to stay with the company."),
    }
    return render_template("index.html", choices=CHOICES, labels=LABELS,
                           form=request.form, errors=[], result=result)


if __name__ == "__main__":
    app.run(debug=True)
