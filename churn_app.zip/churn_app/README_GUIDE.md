# Churn Prediction Flask App – Run & Deploy Guide

## Project structure
```
churn_app/
  app.py                  Flask backend (routes, validation, preprocessing, prediction)
  train_model.py          Re-creates Assignment 1 pipeline and saves model files
  test_app.py             Checks web predictions == notebook model predictions
  requirements.txt
  WA_Fn-UseC_-Telco-Customer-Churn.csv
  model/
    model.joblib          Trained Logistic Regression (best model in Assignment 1)
    scaler.joblib         StandardScaler fitted on training data
    feature_columns.joblib  The 30 feature names in the exact training order
  templates/index.html
  static/style.css
```

## Run locally
```
pip install -r requirements.txt
python train_model.py      # saves the 3 files in model/
python test_app.py         # optional self-test
python app.py              # open http://127.0.0.1:5000
```

## Deploy on PythonAnywhere
1. Create a free account at pythonanywhere.com.
2. **Files** tab -> upload `churn_app.zip` into your home folder, then open a **Bash console** and run:
   `unzip churn_app.zip`
3. In the console:
   ```
   cd ~/churn_app
   pip install --user -r requirements.txt     (or use a virtualenv)
   python train_model.py
   ```
   Re-running train_model.py on PythonAnywhere avoids scikit-learn version mismatch errors with the saved model.
4. **Web** tab -> *Add a new web app* -> *Manual configuration* -> pick the same Python version you used in the console.
5. On the Web tab set **Source code** = `/home/YOURUSERNAME/churn_app`
   (and Virtualenv path if you made one).
6. Click the **WSGI configuration file** link and replace everything with:
   ```python
   import sys
   path = '/home/YOURUSERNAME/churn_app'
   if path not in sys.path:
       sys.path.insert(0, path)
   from app import app as application
   ```
7. (Optional) Static files: URL `/static/` -> Directory `/home/YOURUSERNAME/churn_app/static`
8. Press the green **Reload** button. Visit `https://YOURUSERNAME.pythonanywhere.com`.
   If something breaks, read the **Error log** link on the Web tab.

## Report checklist (screenshots + 2-3 lines each: what / why / result)
1. Saving the model (train_model.py output + model/ folder)
2. Project folder structure
3. index.html + style.css (the form in browser)
4. Key Flask code: validate(), preprocess(), predict()
5. Local run (terminal showing Flask running + browser)
6. Churn prediction result AND No-Churn result (use the two sample customers in test_app.py)
7. Error handling (submit empty form / enter "abc" in tenure)
8. PythonAnywhere: Files tab, Web tab config, WSGI file
9. Final deployed site on the live URL (test again + error case), include the URL
