"""
Re-creates the Assignment 1 pipeline EXACTLY and saves the artifacts for Flask.
Run once locally:  python train_model.py
"""
import pandas as pd, joblib, json
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# --- same preprocessing as Assignment 1 ---
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df = df.dropna(subset=["TotalCharges"])
df = df.drop("customerID", axis=1)
df = pd.get_dummies(df, drop_first=True)

X = df.drop("Churn_Yes", axis=1)
y = df["Churn_Yes"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

# --- Logistic Regression (scaled) vs Decision Tree (as in Assignment 1) ---
lr = LogisticRegression(max_iter=1000).fit(X_train_s, y_train)
dt = DecisionTreeClassifier(random_state=42).fit(X_train, y_train)

def report(name, pred):
    print(f"{name:20s} acc={accuracy_score(y_test,pred):.4f} prec={precision_score(y_test,pred):.4f} "
          f"rec={recall_score(y_test,pred):.4f} f1={f1_score(y_test,pred):.4f}")

report("Logistic Regression", lr.predict(X_test_s))
report("Decision Tree", dt.predict(X_test))

# Best model from Assignment 1 = Logistic Regression (highest accuracy/F1)
joblib.dump(lr, "model/model.joblib")
joblib.dump(scaler, "model/scaler.joblib")
joblib.dump(list(X.columns), "model/feature_columns.joblib")
print("Saved model.joblib, scaler.joblib, feature_columns.joblib")
print("Feature count:", X.shape[1])
