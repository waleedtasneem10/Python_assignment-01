"""Checks that the website gives the same answers as the Assignment 1 model."""
import pandas as pd, joblib
from app import app, model, scaler, feature_columns

raw = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")
raw["TotalCharges"] = pd.to_numeric(raw["TotalCharges"], errors="coerce")
raw = raw.dropna(subset=["TotalCharges"]).reset_index(drop=True)

# Ground truth: the notebook's own pipeline
enc = pd.get_dummies(raw.drop(columns=["customerID"]), drop_first=True)
Xall = enc.drop("Churn_Yes", axis=1)[feature_columns]
truth = model.predict(scaler.transform(Xall))

client = app.test_client()
FIELDS = [c for c in raw.columns if c not in ("customerID", "Churn")]

mismatch, n = 0, 400
for i in range(n):
    row = raw.iloc[i]
    data = {f: str(row[f]) for f in FIELDS}
    html = client.post("/predict", data=data).get_data(as_text=True)
    web_churn = 'class="result churn"' in html
    if web_churn != bool(truth[i]):
        mismatch += 1
print(f"Compared {n} customers: {mismatch} mismatches with the notebook model")

churn_case = dict(gender="Female", SeniorCitizen="1", Partner="No", Dependents="No", tenure="2",
    PhoneService="Yes", MultipleLines="No", InternetService="Fiber optic", OnlineSecurity="No",
    OnlineBackup="No", DeviceProtection="No", TechSupport="No", StreamingTV="Yes",
    StreamingMovies="Yes", Contract="Month-to-month", PaperlessBilling="Yes",
    PaymentMethod="Electronic check", MonthlyCharges="95.5", TotalCharges="190")
stay_case = dict(gender="Male", SeniorCitizen="0", Partner="Yes", Dependents="Yes", tenure="60",
    PhoneService="Yes", MultipleLines="Yes", InternetService="DSL", OnlineSecurity="Yes",
    OnlineBackup="Yes", DeviceProtection="Yes", TechSupport="Yes", StreamingTV="No",
    StreamingMovies="No", Contract="Two year", PaperlessBilling="No",
    PaymentMethod="Bank transfer (automatic)", MonthlyCharges="65", TotalCharges="3900")
for name, case in [("Expected CHURN", churn_case), ("Expected NO CHURN", stay_case)]:
    html = client.post("/predict", data=case).get_data(as_text=True)
    print(name, "->", "Churn" if 'class="result churn"' in html else "No Churn" if 'class="result stay"' in html else "??")

# Validation / error handling
r = client.post("/predict", data={}).get_data(as_text=True)
print("Empty form shows errors:", "Please fix the following" in r)
bad = dict(churn_case, tenure="abc")
print("Bad number handled:", "must be a number" in client.post("/predict", data=bad).get_data(as_text=True))
bad = dict(churn_case, Contract="Weekly")
print("Bad dropdown handled:", "Invalid value" in client.post("/predict", data=bad).get_data(as_text=True))
print("GET / status:", client.get("/").status_code)
